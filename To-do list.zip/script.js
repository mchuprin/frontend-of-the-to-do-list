let allTasks = [];
let input = null;
let inputValue = '';
let activeEditTask = null;

window.onload = function init() {
    input = document.getElementById('add-task')
    input.addEventListener('change', updateValue);
}

onClickButton = () => {
    allTasks.push ( {
        text: inputValue,
        isCheck: false
    })
    input.value = '';
    render ();
}    

updateValue = (event) => {
    inputValue = event.target.value;
} 

render = () => {
    const content = document.getElementById('content');
    while (content.firstChild) {
        content.removeChild(content.firstChild)
    }
    allTasks.sort((a,b) => a.isCheck > b.isCheck ? 1 : a.isCheck < b.isCheck ? -1 : 0)
    allTasks.map ((value, index) => {
        const container = document.createElement('div');
        content.appendChild(container);
        container.className = "task"
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.checked = value.isCheck;
        console.log(checkbox.checked)
        container.appendChild(checkbox)
        checkbox.onchange = function () {
            doneTask(index)
        };
        if(index === activeEditTask) {
            const inputTask = document.createElement('input');
            inputTask.type = 'text';
            inputTask.value = value.text;
            inputTask.addEventListener('change', updateTaskText);
            inputTask.addEventListener('blur', doneEditTask);
            container.appendChild(inputTask);
        } else {
            const text = document.createElement('p');
            text.innerText = value.text;
            container.appendChild(text);
            text.className = value.isCheck ? 'done-task' : 'task-text'; 
        }
        
        if(value.isCheck) {
            if (index === activeEditTask) {
                const imageDone = document.createElement('img');
                imageDone.src = 'done.svg';
                imageDone.onclick = function () {
                    doneEditTask
                }
                container.appendChild(imageDone);
            } else {
                const imageEdit = document.createElement('img');
                imageEdit.src = "pencil.svg";
                imageEdit.onclick = function () {
                    activeEditTask = index;
                    render();
                }
                container.appendChild(imageEdit);
            }

            const imageDelete = document.createElement('img');
            imageDelete.src = "cross.svg";
            imageDelete.onclick = function () {
                deleteTask(index);
            };
            container.appendChild(imageDelete);
        }
       
    });
}

doneTask = (index) => {
    allTasks[index].isCheck = !allTasks[index].isCheck
    render ()
}

deleteTask = (index) => {
    allTasks.splice(index, 1);
    render()
}

updateTaskText = (event) => {
    allTasks[activeEditTask].text = event.target.value;
    render();
}

doneEditTask = () => {
    activeEditTask = null;
    render();
}


// editTask = () => {
//     text = document.getElementById('add-task')
//     text.addEventListener('change', updateValue);
//     const button = document.createElement('button');
//     button = Ok;
// }
